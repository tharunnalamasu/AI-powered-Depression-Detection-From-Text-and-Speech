# Depression Detection from Text and Speech

This project is a Streamlit-based web application that detects signs of depression based on text or speech input using machine learning.

## Features
- Real-time depression detection
- Supports text and voice input
- Basic logistic regression model with TF-IDF
- Clean and simple UI

## Setup

1. Clone the repository or download the zip.
2. Install the required packages:
   ```
   pip install -r requirements.txt
   ```
3. Run the app:
   ```
   streamlit run depression_detection_app.py
   ```

> Make sure your microphone works for speech input.

## Disclaimer
This tool is for educational purposes only and is not a substitute for professional diagnosis.
