import joblib
import pandas as pd
import re
import string
import nltk
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import classification_report, accuracy_score
from nltk.corpus import stopwords
import os

# Download required NLTK data
nltk.download('stopwords', quiet=True)

# Create model directory if it doesn't exist
if not os.path.exists('model'):
    os.makedirs('model')

# Expanded and balanced dataset
texts = [
    # Depressed samples (label = 1)
    "I feel hopeless and tired all the time",
    "I have no interest in anything anymore",
    "Life feels meaningless and empty",
    "I can't sleep and I feel constantly anxious",
    "Everything feels like a burden to me",
    "I'm always sad and can't explain why",
    "I feel empty and completely alone",
    "Nothing excites me or brings joy anymore",
    "I don't see a reason to get out of bed",
    "Crying has become a daily routine for me",
    "I am overwhelmed with deep sadness",
    "I feel numb and disconnected from everything",
    "I want to give up on everything in life",
    "I feel like a complete failure",
    "I'm constantly worried and stressed about everything",
    "I am losing all hope for the future",
    "I feel isolated and cut off from the world",
    "My energy is completely gone",
    "I have serious trouble concentrating on anything",
    "I feel like nobody understands or cares about me",
    "I hate myself and feel worthless",
    "I'm drowning in despair and darkness",
    "I feel trapped with no way out",
    "Life is unbearable and painful",
    "I feel broken and damaged beyond repair",
    "I have lost all motivation to do anything",
    "I feel like I'm a burden to everyone",
    "I can't stop these negative thoughts",
    "I feel dead inside and emotionally numb",
    "I'm struggling to find any meaning in life",
    "Everything seems pointless and futile",
    "I feel consumed by overwhelming sadness",
    "I'm exhausted from pretending to be okay",
    "I feel like giving up on everything",
    "I'm lost and don't know how to feel better",
    "I feel like I'm falling into a dark hole",
    "I'm tired of feeling this way constantly",
    "I feel like I'm suffocating emotionally",
    "I have no energy or will to continue",
    "I feel like my life is falling apart",

    # Not Depressed samples (label = 0)
    "Life is great and I'm very happy",
    "I enjoy spending time with my family and friends",
    "I am feeling fantastic and energetic today",
    "I'm excited about my new job and opportunities",
    "I had a wonderful time with friends yesterday",
    "Today is a beautiful and good day",
    "I love my life and the people around me",
    "I'm optimistic and hopeful about the future",
    "I feel relaxed, calm, and at peace",
    "I'm happy with my progress and achievements",
    "I am grateful and thankful for what I have",
    "I feel energetic, motivated, and ready to go",
    "I look forward to new experiences and adventures",
    "I am confident in myself and my abilities",
    "I enjoy learning new things every day",
    "I feel peaceful, content, and satisfied",
    "I have strong support from my friends and family",
    "I am positive about my health and wellbeing",
    "I love spending time outdoors in nature",
    "I feel hopeful, inspired, and uplifted",
    "I'm thrilled about the weekend plans",
    "I feel blessed and fortunate in life",
    "I'm enjoying every moment of today",
    "I feel accomplished and proud of myself",
    "I'm laughing and having so much fun",
    "I feel alive and full of energy",
    "I'm grateful for this beautiful day",
    "I feel joy and happiness in my heart",
    "I'm excited to meet new people",
    "I feel strong and capable of anything",
    "I'm happy with who I am becoming",
    "I feel refreshed and renewed today",
    "I'm celebrating my recent success",
    "I feel loved and appreciated by others",
    "I'm enthusiastic about my hobbies",
    "I feel motivated to achieve my goals",
    "I'm enjoying good health and vitality",
    "I feel optimistic about tomorrow",
    "I'm happy to be alive and healthy",
    "I feel fulfilled and purposeful in life",
    
    # Additional positive phrases to handle common happy expressions
    "I am happy",
    "I feel happy today",
    "I'm so happy right now",
    "I am really happy",
    "I feel good and happy",
    "I'm feeling happy and excited",
    "I am incredibly happy",
    "I feel happy and content",
    "I'm genuinely happy",
    "I am very happy with my life"
]

labels = [
    # 40 Depressed samples
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    # 50 Not Depressed samples (including specific happy phrases)
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
]

def preprocess_text(text):
    """Enhanced preprocessing function"""
    text = text.lower()
    text = re.sub(f"[{string.punctuation}]", "", text)
    words = text.split()
    stop_words = set(stopwords.words('english'))
    # Keep some important words that might be filtered out
    important_words = {'not', 'no', 'never', 'happy', 'sad', 'good', 'bad', 'great', 'terrible'}
    filtered = [w for w in words if w not in stop_words or w in important_words]
    return " ".join(filtered)

# Preprocess all texts
processed_texts = [preprocess_text(text) for text in texts]

# Create DataFrame for better data handling
df = pd.DataFrame({
    'text': texts,
    'processed_text': processed_texts,
    'label': labels
})

print(f"Dataset size: {len(df)}")
print(f"Depressed samples: {sum(labels)}")
print(f"Non-depressed samples: {len(labels) - sum(labels)}")

# Split the dataset
X_train, X_test, y_train, y_test = train_test_split(
    processed_texts, labels, test_size=0.2, random_state=42, stratify=labels
)

# Create improved pipeline with better parameters
pipeline = Pipeline([
    ('vectorizer', TfidfVectorizer(
        max_features=5000,
        ngram_range=(1, 2),  # Include both unigrams and bigrams
        min_df=1,
        max_df=0.95,
        stop_words=None  # We already preprocessed
    )),
    ('classifier', RandomForestClassifier(
        n_estimators=200,
        max_depth=10,
        min_samples_split=2,
        min_samples_leaf=1,
        random_state=42,
        class_weight='balanced'  # Handle class imbalance
    ))
])

# Train the model
print("Training the model...")
pipeline.fit(X_train, y_train)

# Evaluate on test data
y_pred = pipeline.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)

print(f"\nAccuracy: {accuracy:.4f}")
print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=['Not Depressed', 'Depressed']))

# Cross-validation for better evaluation
cv_scores = cross_val_score(pipeline, processed_texts, labels, cv=5, scoring='accuracy')
print(f"\nCross-validation scores: {cv_scores}")
print(f"Average CV accuracy: {cv_scores.mean():.4f} (+/- {cv_scores.std() * 2:.4f})")

# Test with specific examples
test_examples = [
    "I am happy",
    "I feel happy today",
    "I'm so happy right now",
    "I feel sad and hopeless",
    "I'm depressed and tired",
    "Life is great",
    "I feel terrible and worthless"
]

print("\nTesting specific examples:")
for example in test_examples:
    processed_example = preprocess_text(example)
    prediction = pipeline.predict([processed_example])[0]
    probability = pipeline.predict_proba([processed_example])[0]
    result = "Depressed" if prediction == 1 else "Not Depressed"
    confidence = max(probability)
    print(f"'{example}' -> {result} (Confidence: {confidence:.3f})")

# Save the components
print("\nSaving model components...")
joblib.dump(pipeline.named_steps['vectorizer'], "model/vectorizer.pkl")
joblib.dump(pipeline.named_steps['classifier'], "model/depression_model.pkl")

# Also save the preprocessing function for consistency
import pickle
with open("model/preprocessor.pkl", "wb") as f:
    pickle.dump(preprocess_text, f)

print("Model training completed and saved successfully!")
print("Files saved:")
print("- model/vectorizer.pkl")
print("- model/depression_model.pkl") 
print("- model/preprocessor.pkl")