import streamlit as st
import speech_recognition as sr
import joblib
import pickle
import re
import string
import nltk
from nltk.corpus import stopwords
import os

# Download required NLTK data
try:
    nltk.download('stopwords', quiet=True)
except:
    pass

# Load the trained model components
@st.cache_resource
def load_model():
    try:
        vectorizer = joblib.load("model/vectorizer.pkl")
        model = joblib.load("model/depression_model.pkl")
        
        # Try to load the preprocessor if it exists
        try:
            with open("model/preprocessor.pkl", "rb") as f:
                preprocessor = pickle.load(f)
        except:
            # Fallback to default preprocessor
            def preprocessor(text):
                text = text.lower()
                text = re.sub(f"[{string.punctuation}]", "", text)
                words = text.split()
                try:
                    stop_words = set(stopwords.words('english'))
                    important_words = {'not', 'no', 'never', 'happy', 'sad', 'good', 'bad', 'great', 'terrible'}
                    filtered = [w for w in words if w not in stop_words or w in important_words]
                    return " ".join(filtered)
                except:
                    return " ".join(words)
        
        return vectorizer, model, preprocessor
    except Exception as e:
        st.error(f"Error loading model: {e}")
        st.error("Please run train_model.py first to create the model files.")
        return None, None, None

def detect_depression(text, vectorizer, model, preprocessor):
    """Detect depression from text with confidence score"""
    try:
        # Preprocess the text
        processed_text = preprocessor(text)
        
        # Transform using the vectorizer
        features = vectorizer.transform([processed_text])
        
        # Get prediction and probability
        prediction = model.predict(features)[0]
        probability = model.predict_proba(features)[0]
        confidence = max(probability)
        
        return prediction, confidence
    except Exception as e:
        st.error(f"Error in prediction: {e}")
        return None, None

def speech_to_text():
    """Convert speech to text using microphone"""
    recognizer = sr.Recognizer()
    try:
        with sr.Microphone() as source:
            st.info("🎤 Listening... Please speak now.")
            # Adjust for ambient noise
            recognizer.adjust_for_ambient_noise(source, duration=1)
            # Listen for audio with timeout
            audio = recognizer.listen(source, timeout=10, phrase_time_limit=15)
            
        st.info("🔄 Processing speech...")
        # Recognize speech using Google Web Speech API
        text = recognizer.recognize_google(audio)
        return text
    except sr.WaitTimeoutError:
        return "Timeout: No speech detected. Please try again."
    except sr.UnknownValueError:
        return "Could not understand the audio. Please speak clearly and try again."
    except sr.RequestError as e:
        return f"Speech recognition service error: {e}"
    except Exception as e:
        return f"An error occurred: {e}"

# Main Streamlit App
def main():
    st.set_page_config(
        page_title="Depression Detection Tool",
        page_icon="🧠",
        layout="wide"
    )
    
    st.title("🧠 Depression Detection from Text and Speech")
    st.markdown("---")
    
    # Load model
    vectorizer, model, preprocessor = load_model()
    
    if vectorizer is None or model is None:
        st.error("❌ Model not loaded. Please run `train_model.py` first.")
        st.stop()
    
    st.success("✅ Model loaded successfully!")
    
    # Sidebar with information
    with st.sidebar:
        st.header("ℹ️ About")
        st.write("This tool uses machine learning to analyze text or speech for signs of depression.")
        st.write("**How it works:**")
        st.write("1. Input text directly or use speech recognition")
        st.write("2. Text is processed and analyzed")
        st.write("3. AI model predicts depression likelihood")
        
        st.header("🎯 Accuracy Tips")
        st.write("• Be specific about your feelings")
        st.write("• Use complete sentences")
        st.write("• Speak clearly for speech input")
        
        st.header("⚠️ Important")
        st.warning("This tool is for educational purposes only and should not replace professional mental health consultation.")
    
    # Main interface
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("Choose Input Method")
        input_mode = st.radio(
            "Select how you want to provide input:",
            ["💬 Text Input", "🎤 Speech Input"],
            horizontal=True
        )
        
        if input_mode == "💬 Text Input":
            st.subheader("Text Analysis")
            user_input = st.text_area(
                "Share your thoughts or feelings:",
                placeholder="Type how you're feeling today...",
                help="Describe your current emotional state, thoughts, or feelings.",
                height=150
            )
            
            if st.button("🔍 Analyze Text", type="primary"):
                if user_input.strip():
                    with st.spinner("Analyzing your input..."):
                        prediction, confidence = detect_depression(user_input, vectorizer, model, preprocessor)
                        
                        if prediction is not None:
                            # Display results
                            st.markdown("### 📊 Analysis Results")
                            
                            if prediction == 1:
                                st.error(f"⚠️ **Signs of Depression Detected**")
                                st.error(f"Confidence: {confidence:.1%}")
                                st.info("💡 **Recommendation:** Consider speaking with a mental health professional.")
                            else:
                                st.success(f"✅ **No Signs of Depression Detected**")
                                st.success(f"Confidence: {confidence:.1%}")
                                st.info("💡 **Great!** Continue taking care of your mental health.")
                else:
                    st.warning("⚠️ Please enter some text to analyze.")
        
        elif input_mode == "🎤 Speech Input":
            st.subheader("Speech Analysis")
            st.write("Click the button below and speak about your feelings.")
            
            if st.button("🎤 Start Recording", type="primary"):
                with st.spinner("Preparing microphone..."):
                    transcribed_text = speech_to_text()
                
                st.subheader("📝 Transcribed Text")
                st.write(f"**You said:** {transcribed_text}")
                
                if not transcribed_text.startswith(("Timeout:", "Could not understand", "Speech recognition service error:", "An error occurred:")):
                    with st.spinner("Analyzing your speech..."):
                        prediction, confidence = detect_depression(transcribed_text, vectorizer, model, preprocessor)
                        
                        if prediction is not None:
                            st.markdown("### 📊 Analysis Results")
                            
                            if prediction == 1:
                                st.error(f"⚠️ **Signs of Depression Detected**")
                                st.error(f"Confidence: {confidence:.1%}")
                                st.info("💡 **Recommendation:** Consider speaking with a mental health professional.")
                            else:
                                st.success(f"✅ **No Signs of Depression Detected**")
                                st.success(f"Confidence: {confidence:.1%}")
                                st.info("💡 **Great!** Continue taking care of your mental health.")
                else:
                    st.error(f"❌ {transcribed_text}")
    # Footer
    st.markdown("---")
    st.markdown(
        """
        <div style='text-align: center; color: #666;'>
            <p><strong>Disclaimer:</strong> This tool is for educational and research purposes only. 
            It is not intended to diagnose, treat, cure, or prevent any mental health condition. 
            Please consult with qualified mental health professionals for proper diagnosis and treatment.</p>
            <p>If you're experiencing thoughts of self-harm, please contact emergency services or a crisis helpline immediately.</p>
        </div>
        """, 
        unsafe_allow_html=True
    )

if __name__ == "__main__":
    main()